import React from "react";

const Breadcrumb = () => {
  return (
    <section className="page-banner-section">
      <div className="container">
        <h1>List Style</h1>
        <span>12 Posts</span>
      </div>
    </section>
  );
};

export default Breadcrumb;
