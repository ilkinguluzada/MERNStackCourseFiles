module.exports = {
  MONGOURI:
    "mongodb+srv://ilkinguluzada:completeblog@cluster0-42cnj.mongodb.net/test?retryWrites=true&w=majority",
};
